import java.util.Random;
import java.util.Scanner;

public class UsuarioAdmin extends Usuario {

	public UsuarioAdmin(int codigo, String senha) {
		super(codigo, senha);
		this.codigo = 0000000;
		this.senha  = "admin";
	}
	
	public void adiconarUsuario(){
		Scanner c = new Scanner (System.in);
		System.out.println("Digite as informa��es do Usuario a ser adicionado");
		System.out.println("Nome:");
		String n = c.nextLine();
		
		System.out.println("Telefone:");
		int t = c.nextInt();
		
		System.out.println("Email: ");
		String e = c.nextLine();
		
		System.out.println("Endere�o: ");
		String end = c.nextLine();
		
		System.out.println("Cpf: ");
		int cpf = c.nextInt();
		
		System.out.println("Tipo de usu�rio:\n1 - Aluno Gradua��o\n2 - Aluno Especializa��o\n3 - Professor\n4 - Funcionario");
		int tipo = c.nextInt();
		
		Random gerador = new Random();
		int cod = gerador.nextInt(999999) + 1;
		String sen = "default";
		
		UsuarioNormal u = new UsuarioNormal(cod,sen,n, t, e, end, tipo, cpf);
		GerenciadorBiblioteca.setListaUsuarios(u);
		c.close();
		
	}
	public void adicionarItem(){
		Scanner c = new Scanner (System.in);
		System.out.println("Digite as informa��es do Item a ser adicionado");
		System.out.println("Titulo: ");
		String e = c.nextLine();
		
		System.out.println("Tipo: ");
		String end = c.nextLine();
		
	}
	public void bloquearUsuario(){
		
	}
	public void realizarEmprestimo(){
		
	}
	public void realizarDevolucao(){
		
	}
	public void receberDoacao(){
		
	}

}
