
public class UsuarioNormal extends Usuario{
	public String nome;
	public int tel;
	public String email;
	public String end;
	public int tipoUsuario;
	public int cpf;
	public int limiteItensAlugados;
	public int limiteDias;
	
	/**
	  DICIONARIO
		1 -> Aluno Gradua��o
		2 -> Aluno Especializa��o
		3 -> Professor
		4 -> Funcionario
	*/
	
	
	public UsuarioNormal(int codigo, String senha, String nome, int tel, String email, String end, int tipoUsuario,
			int cpf) {
		super(codigo, senha);
		this.nome = nome;
		this.tel = tel;
		this.email = email;
		this.end = end;
		this.tipoUsuario = tipoUsuario;
		this.cpf = cpf;
		
		if(tipoUsuario == 1){
			this.limiteDias = 15;
			this.limiteItensAlugados = 5;
		}
		if(tipoUsuario == 2){
			this.limiteDias = 20;
			this.limiteItensAlugados = 7;
		}
		if(tipoUsuario == 3){
			this.limiteDias = 25;
			this.limiteItensAlugados = 3;
		}
		if(tipoUsuario == 4){
			this.limiteDias = 20;
			this.limiteItensAlugados = 3;
		}
	}
	
	public int getLimiteItensAlugados() {
		return limiteItensAlugados;
	}
	public int getLimiteDias() {
		return limiteDias;
	}
	
	public static void PesquisarItem (){
		
	}
	
	public static void RezervaItem (){
		
	}
	
	
	public static void AvisoDevolucao(int limiteItensAlugados){
		if(limiteItensAlugados == 3){
			System.out.println("Falta 2 dia(s) para a realizar a devoluçao gratis (Após os 5 dias de devoluçao gratis será cobrada uma taxa de devoluçao)");
		}
		if(limiteItensAlugados == 4){
			System.out.println("Falta 1 dia(s) para a realizar a devoluçao gratis (Após os 5 dias de devoluçao gratis será cobrada uma taxa de devoluçao)");
		}
		if(limiteItensAlugados == 5){
			System.out.println("Falta 0 dia(s) para a realizar a devoluçao gratis (Após os 5 dias de devoluçao gratis será cobrada uma taxa de devoluçao)");
		}
	}
}
