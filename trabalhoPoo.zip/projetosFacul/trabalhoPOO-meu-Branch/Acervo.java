import java.util.ArrayList;
import java.util.List;

public class Acervo {
	public List<Item> acervo = new ArrayList<Item>();
	
}
