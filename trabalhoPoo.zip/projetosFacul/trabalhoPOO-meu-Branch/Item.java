import java.util.Date;
import java.text.SimpleDateFormat;

public class Item {
	
	// tipoItems : 1 - Livros , 2 - Revistas e 3 - Periodicos .
	
	protected String titulo;
	protected int tipoItem;
	protected Date dataEmprestimo;
	protected Date entregaPrevista;
	protected SimpleDateFormat form = new SimpleDateFormat("dd/MM/yyyy");
	
	public Item(String titulo, int tipoItem) {
		super();
		this.titulo = titulo;
		this.tipoItem = tipoItem;
		this.dataEmprestimo = new Date();
		form.format(dataEmprestimo);
		if (tipoItem == 1){
			this.entregaPrevista = this.dataEmprestimo;
			//this.entregaPrevista.s;       ajeitar controle de data
		}
		if (tipoItem == 2){
			//this.entregaPrevista = dataEmprestimo + 10;  ajeitar controle de data
		}
		if (tipoItem == 3){
			//this.entregaPrevista = dataEmprestimo + 5;     ajeitar controle de data
		}
	}
	
	public static double calcularMulta(int diasExcedidos){
		return diasExcedidos * 1.50;
	}
	
	public static void calcularDiaEntrega(int entregaPrevista){
		System.out.println("Dia de entrega :" + entregaPrevista);
	}
}

