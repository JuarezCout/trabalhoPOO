import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GerenciadorBiblioteca {
	public GerenciadorBiblioteca (){
		
	}
	public static List<UsuarioNormal> listaUsuarios = new ArrayList<UsuarioNormal>();
	public static List<Item> listaItens             = new ArrayList<Item>();
	public static Map<UsuarioNormal, List<Item>> map = new HashMap<UsuarioNormal, List<Item>>();
	
	public List<UsuarioNormal> getListaUsuarios() {
		return listaUsuarios;
	}
	public static void setListaUsuarios(UsuarioNormal usuario) {
		listaUsuarios.add(usuario);
	}
	public List<Item> getListaItens() {
		return listaItens;
	}
	public static void setListaItens(Item item) {
		listaItens.add(item);
	}
}
