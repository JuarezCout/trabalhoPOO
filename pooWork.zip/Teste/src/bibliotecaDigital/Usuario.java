package bibliotecaDigital;

public class Usuario {
	protected static int codigo ;
	protected static String senha ;

	public Usuario(int codigo, String senha) {
		super();
		this.codigo = codigo;
		this.senha = senha;
	}
	
	public int getCodigo() {
		return codigo;
	}
	public String getSenha() {
		return senha;
	}
}