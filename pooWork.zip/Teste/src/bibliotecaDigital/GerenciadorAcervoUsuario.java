package bibliotecaDigital;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GerenciadorAcervoUsuario {
	public List<Usuario> usuarios = new ArrayList<Usuario>();
	public List<Item> itens = new ArrayList<Item>();
	
	public Map<Usuario, Item> mapaGerenciador = new HashMap<Usuario, Item>();
	
	
}
