package bibliotecaDigital;

import java.util.Scanner;

public class UsuarioAdmin extends Usuario {
	Scanner c = new Scanner(System.in);
	public UsuarioAdmin (){
		super(codigo, senha);
	}
	
	public void adiconarUsuario(){
		System.out.println("Digite o nome:");
		System.out.println("Digite o endere�o:");
		System.out.println("Digite o cpf:");
		System.out.println("Digite o telefone:");
		System.out.println("Digite o Tipo de Usuario:");
		System.out.println("Digite o email:");
		//adicionar num objeto de Usuario e Salvar no mapa
	}
	public void adicionarLivro(){
		;
	}
	public void bloquearusuario(){
		;
	}
	public void realizarEmprestimo(){
		;
	}
	public void realizarDevolucao(){
		;
	}
	public void receberDoacao(){;
	
	}


}
