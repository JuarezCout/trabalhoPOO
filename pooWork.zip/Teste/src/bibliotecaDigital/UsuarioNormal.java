package bibliotecaDigital;

public class UsuarioNormal extends Usuario{
	protected String nome;
	protected int tel;
	protected String email;
	protected String end;
	protected int tipoUsuario;
	protected int cpf;
	protected int limiteItensAlugados;
	protected int limiteDias;
	
	
	
	public UsuarioNormal(int codigo, String senha, String nome, int tel, String email, String end, int tipoUsuario,
		int cpf, int limiteItensAlugados, int limiteDias) {
		super(codigo, senha);
		this.nome = nome;
		this.tel = tel;
		this.email = email;
		this.end = end;
		this.tipoUsuario = tipoUsuario;
		this.cpf = cpf;
		this.limiteItensAlugados = limiteItensAlugados;
		this.limiteDias = limiteDias;
	}
	
	public int getLimiteItensAlugados() {
		return limiteItensAlugados;
	}
	public int getLimiteDias() {
		return limiteDias;
	}
	
	public static void PesquisarItem (){
		
	}
	
	public static void ReservaItem (){
		
	}
	
	
	public void AvisoDevolu�ao (int limiteDias){
		if(limiteDias == 3){
			System.out.println("Falta 2 dia(s) para a realizar a devolu�ao gratis (Ap�s os 5 dias de devolu�ao gratis ser� cobrada uma taxa de devolu�ao)");
		}
		if(limiteDias == 4){
			System.out.println("Falta 1 dia(s) para a realizar a devolu�ao gratis (Ap�s os 5 dias de devolu�ao gratis ser� cobrada uma taxa de devolu�ao)");
		}
		if(limiteDias == 5){
			System.out.println("Falta 0 dia(s) para a realizar a devolu�ao gratis (Ap�s os 5 dias de devolu�ao gratis ser� cobrada uma taxa de devolu�ao)");
		}
	}
}
